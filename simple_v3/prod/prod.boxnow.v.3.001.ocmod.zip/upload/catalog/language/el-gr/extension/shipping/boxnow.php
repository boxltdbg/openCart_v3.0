<?php
// Text
$_['text_title']       = 'Αποστολή μέσω BoxNow';
$_['text_description'] = 'BoxNow Express (Παράδοση σε Αυτόματο Μηχάνημα Παραλαβής)';
$_['text_select_lockerid'] = 'Θα πρέπει να επιλέξετε κάποιο Locker για να συνεχίσετε.';
$_['error_boxnow'] 	= 'Δεν έχετε επιλέξει locker!';
$_['selected_boxnow'] = 'Επιλεγμένο Locker:';