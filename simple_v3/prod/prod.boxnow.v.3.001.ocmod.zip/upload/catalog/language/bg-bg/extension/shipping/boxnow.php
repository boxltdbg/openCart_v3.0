<?php
// Text
$_['text_title']       = 'Доставка чрез BOX NOW';
$_['text_description'] = 'BOX NOW';
$_['text_select_lockerid'] = 'Нужно е да изберете автомат, за да продължите.';
$_['error_boxnow'] 	= 'Не сте избрали автомат!';
$_['selected_boxnow'] = 'Избран автомат:';