<?php
// Text
$_['text_title']       = 'BOX NOW';
$_['text_description'] = 'BOX NOW';
$_['text_select_lockerid'] = 'Необходимо е да изберете BOX NOW автомат за да продължите.';
$_['error_boxnow'] 	= 'Моля изберете BOX NOW автомат!';
$_['selected_boxnow'] = 'Избран автомат:';