<?php
// Text
$_['text_title']       = 'Shipping via BoxNow';
$_['text_description'] = 'Boxnow Delivery Service';
$_['text_select_lockerid'] = 'You must select a Locker to continue.';
$_['error_boxnow'] 	= 'You have not selected a locker!';
$_['selected_boxnow'] = 'Selected Locker:';