<?php
// Text
$_['text_title']       = 'Изпрати чрез BOX NOW';
$_['text_description'] = 'Модул за доставки на BOX NOW';
$_['text_select_lockerid'] = 'Нужно е да изберете автомат, за да продължите.';
$_['error_boxnow'] 	= 'Не сте избрали BOX NOW Автомат!';
$_['selected_boxnow'] = 'Избран BOX NOW Автомат:';